﻿#Requires -Version 2  # Win7 built-in PS 2.0; script body is PS2-compatible syntax only (r116)
<#
    TCraft Launcher 卸载清理脚本
    ------------------------------------------------------------------
    本文件是嵌入资源模板，由启动器在卸载时复制到
    %TEMP%\TCL_Uninstall\uninstall_<时间戳>.ps1 并以分离进程启动。
    启动器会在脚本启动后立即结束自身进程；脚本先等待父进程退出，
    再延迟数秒（默认 3 秒）才开始清理，确保所有文件句柄都已释放。

    清理范围全部来自启动器生成的白名单清单，通过 -Targets / -RegKeys
    传入，脚本内部会再校验一次（纵深防御）：
      DIR|<路径>            递归删除目录（目录名必须为 TCL）
      DIR_IF_EMPTY|<路径>   仅当目录为空时删除（用于安装目录本身）
      FILE|<路径>           删除单个文件
      KEY|<HKCU 路径>       删除整个注册表项（仅允许 HKCU\Software\ 之下）
      VAL|<HKCU 路径>|<值名> 删除单个注册表值（绝不删除整个项）

    -InstallDir 用于校验 DIR_IF_EMPTY 的路径确实就是启动器安装目录。

    安全约束：
      * 不接受通配符、相对路径、上级目录引用、驱动器根目录；
      * 不删除系统目录、用户配置目录、桌面、Program Files 等受保护位置本身；
      * 不跨越 junction / 符号链接递归，链接只删除链接本身；
      * 任何一步失败都只记录日志并继续后续步骤，不会中断。

    执行结束后脚本会自毁；若存在失败项，日志会保留以便排查。
#>
[CmdletBinding()]
param(
    [string]$Targets = '',
    [string]$RegKeys = '',
    [string]$LogPath = '',
    [string]$InstallDir = '',
    [int]$ParentPid = 0,
    [int]$DelaySeconds = 3,
    [switch]$KeepLog
)

$ErrorActionPreference = 'Continue'

$script:OkCount = 0
$script:SkipCount = 0
$script:FailCount = 0
$script:Protected = @()
$script:AllowedRoots = @()

function Write-Log {
    param([string]$Level, [string]$Message)
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    if (-not [string]::IsNullOrWhiteSpace($LogPath)) {
        try { Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8 -ErrorAction Stop } catch { }
    }
}

function Normalize-Path {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return '' }
    $p = $Value.Trim().Trim('"')
    try { $p = [System.IO.Path]::GetFullPath($p) } catch { }
    return $p.TrimEnd('\')
}

function Get-ProtectedPaths {
    $list = New-Object System.Collections.Generic.List[string]
    $ids = @(
        'Windows', 'System', 'SystemX86', 'ProgramFiles', 'ProgramFilesX86',
        'UserProfile', 'Desktop', 'DesktopDirectory', 'MyDocuments',
        'ApplicationData', 'LocalApplicationData', 'CommonApplicationData',
        'StartMenu', 'Programs', 'CommonStartMenu', 'CommonDesktopDirectory', 'CommonPrograms'
    )
    foreach ($id in $ids) {
        try {
            $p = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]$id)
            if (-not [string]::IsNullOrWhiteSpace($p)) { $list.Add((Normalize-Path $p)) }
        } catch { }
    }
    $envs = @($env:SystemRoot, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData,
              $env:USERPROFILE, $env:TEMP, $env:APPDATA, $env:LOCALAPPDATA, $env:PUBLIC)
    foreach ($v in $envs) {
        if (-not [string]::IsNullOrWhiteSpace($v)) { $list.Add((Normalize-Path $v)) }
    }
    try {
        foreach ($d in [System.IO.DriveInfo]::GetDrives()) { $list.Add((Normalize-Path $d.RootDirectory.FullName)) }
    } catch { }
    return ($list | Where-Object { $_ } | Sort-Object -Unique)
}

# 返回 $null 表示通过校验，否则返回拒绝原因
function Test-SafePath {
    param([string]$Path, [string]$Kind)

    if ([string]::IsNullOrWhiteSpace($Path)) { return '路径为空' }
    if ($Path -match '[*?]') { return '包含通配符' }
    if (($Path -split '[\\/]') -contains '..') { return '包含上级目录引用' }
    if (-not [System.IO.Path]::IsPathRooted($Path)) { return '不是绝对路径' }
    if ($Path -match '\.minecraft') { return '涉及 .minecraft，禁止删除' }

    $full = Normalize-Path $Path
    if ($full.Length -le 2) { return '不允许删除驱动器根目录' }

    foreach ($p in $script:Protected) {
        if ([string]::Equals($full, $p, [System.StringComparison]::OrdinalIgnoreCase)) {
            return "目标是受保护的系统或用户位置：$p"
        }
        if ($p.StartsWith($full + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
            return "目标是受保护位置的上级目录：$p"
        }
    }

    if ($Kind -eq 'Dir') {
        $leaf = [System.IO.Path]::GetFileName($full)
        if (-not [string]::Equals($leaf, 'TCL', [System.StringComparison]::OrdinalIgnoreCase)) {
            return "目录名不是 TCL，拒绝递归删除（$leaf）"
        }
    }

    if ($Kind -eq 'DirIfEmpty') {
        # 安装目录本身就是允许的根，只需确认它与参数一致即可
        if ([string]::IsNullOrWhiteSpace($InstallDir) -or
            -not [string]::Equals($full, (Normalize-Path $InstallDir), [System.StringComparison]::OrdinalIgnoreCase)) {
            return '目录不是启动器安装目录'
        }
        return $null
    }

    # 只允许操作启动器安装目录、桌面、开始菜单、AppData 与临时目录内的内容
    $inside = $false
    foreach ($r in $script:AllowedRoots) {
        if ($full.StartsWith($r + '\', [System.StringComparison]::OrdinalIgnoreCase)) { $inside = $true; break }
    }
    if (-not $inside) { return '不在启动器安装目录、桌面、开始菜单、AppData 或临时目录内' }
    return $null
}

function Remove-FileWithRetry {
    param([string]$Path, [int]$Attempts = 3)

    for ($i = 1; $i -le $Attempts; $i++) {
        try {
            if (Test-Path -LiteralPath $Path) {
                $item = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
                if (([int]$item.Attributes -band [int][System.IO.FileAttributes]::ReadOnly) -ne 0) {
                    $item.Attributes = $item.Attributes -band (-bnot [System.IO.FileAttributes]::ReadOnly)
                }
            }
            [System.IO.File]::Delete($Path)
            if (Test-Path -LiteralPath $Path) { throw '文件仍然存在' }
            $script:OkCount++
            Write-Log 'OK' "已删除文件：$Path"
            return $true
        } catch {
            if ($i -eq $Attempts) {
                $script:FailCount++
                Write-Log 'FAIL' "删除文件失败：$Path → $($_.Exception.Message)"
                return $false
            }
            Start-Sleep -Milliseconds 500
        }
    }
    return $false
}

# 显式逐层删除：不使用 -Recurse，不跟随 junction / 符号链接
function Remove-SafeTree {
    param([string]$Dir, [int]$Depth = 0)

    if ($Depth -gt 64) {
        $script:FailCount++
        Write-Log 'FAIL' "目录层级异常（超过 64 层），已停止：$Dir"
        return
    }

    $children = @()
    try { $children = @(Get-ChildItem -LiteralPath $Dir -Force -ErrorAction Stop) }
    catch {
        $script:FailCount++
        Write-Log 'FAIL' "无法枚举目录：$Dir → $($_.Exception.Message)"
        return
    }

    foreach ($child in $children) {
        $isLink = (([int]$child.Attributes -band [int][System.IO.FileAttributes]::ReparsePoint) -ne 0)
        if ($child.PSIsContainer) {
            if ($isLink) {
                # 只删除链接本身，绝不进入，避免顺着 junction 删到目录之外
                try {
                    [System.IO.Directory]::Delete($child.FullName, $false)
                    $script:OkCount++
                    Write-Log 'OK' "已删除目录链接：$($child.FullName)"
                } catch {
                    $script:FailCount++
                    Write-Log 'FAIL' "删除目录链接失败：$($child.FullName) → $($_.Exception.Message)"
                }
            } else {
                Remove-SafeTree -Dir $child.FullName -Depth ($Depth + 1)
            }
        } else {
            Remove-FileWithRetry -Path $child.FullName | Out-Null
        }
    }

    try {
        $left = @([System.IO.Directory]::GetFileSystemEntries($Dir))
        if ($left.Count -eq 0) {
            [System.IO.Directory]::Delete($Dir, $false)
            $script:OkCount++
            Write-Log 'OK' "已删除目录：$Dir"
        } else {
            $script:SkipCount++
            Write-Log 'SKIP' "目录仍有 $($left.Count) 个条目无法删除，保留：$Dir"
        }
    } catch {
        $script:FailCount++
        Write-Log 'FAIL' "删除目录失败：$Dir → $($_.Exception.Message)"
    }
}

# 只接受 HKCU\Software\ 之下、至少两级的键，返回相对 CurrentUser 的子键路径
function ConvertTo-RegSubKey {
    param([string]$Key)

    if ([string]::IsNullOrWhiteSpace($Key)) { return $null }
    $k = $Key.Trim().Replace('/', '\')
    if ($k -match '^(?i)HKCU\\') { $k = 'HKEY_CURRENT_USER\' + $k.Substring(5) }
    if ($k -notmatch '^(?i)HKEY_CURRENT_USER\\Software\\') { return $null }
    if ($k -match '[*?]') { return $null }
    if (($k -split '\\') -contains '..') { return $null }
    $sub = $k.Substring('HKEY_CURRENT_USER\'.Length)
    $segments = @($sub.Split('\') | Where-Object { $_ -ne '' })
    if ($segments.Count -lt 2) { return $null }
    return ($segments -join '\')
}

function Remove-RegKey {
    param([string]$KeyPath)

    $sub = ConvertTo-RegSubKey $KeyPath
    if (-not $sub) {
        $script:SkipCount++
        Write-Log 'SKIP' "注册表项不在白名单规则内，已跳过：$KeyPath"
        return
    }
    $base = $null
    $probe = $null
    try {
        $base = [Microsoft.Win32.Registry]::CurrentUser
        $probe = $base.OpenSubKey($sub, $false)
        if ($null -eq $probe) {
            $script:SkipCount++
            Write-Log 'SKIP' "注册表项不存在，已跳过：$KeyPath"
            return
        }
        $probe.Close()
        $probe = $null
        $base.DeleteSubKeyTree($sub, $false)
        $script:OkCount++
        Write-Log 'OK' "已删除注册表项：$KeyPath"
    } catch {
        $script:FailCount++
        Write-Log 'FAIL' "删除注册表项失败：$KeyPath → $($_.Exception.Message)"
    } finally {
        if ($null -ne $probe) { $probe.Close() }
    }
}

function Remove-RegValue {
    param([string]$KeyPath, [string]$ValueName)

    $sub = ConvertTo-RegSubKey $KeyPath
    if (-not $sub) {
        $script:SkipCount++
        Write-Log 'SKIP' "注册表项不在白名单规则内，已跳过：$KeyPath"
        return
    }
    if ([string]::IsNullOrEmpty($ValueName)) {
        $script:SkipCount++
        Write-Log 'SKIP' "注册表值名为空，已跳过：$KeyPath"
        return
    }

    $handle = $null
    try {
        $handle = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($sub, $true)
        if ($null -eq $handle) {
            $script:SkipCount++
            Write-Log 'SKIP' "注册表项不存在，已跳过：$KeyPath"
            return
        }
        if (@($handle.GetValueNames()) -notcontains $ValueName) {
            $script:SkipCount++
            Write-Log 'SKIP' "注册表值不存在，已跳过：$KeyPath → $ValueName"
            return
        }
        $handle.DeleteValue($ValueName, $false)
        $script:OkCount++
        Write-Log 'OK' "已删除注册表值：$KeyPath → $ValueName"
    } catch {
        $script:FailCount++
        Write-Log 'FAIL' "删除注册表值失败：$KeyPath → $ValueName → $($_.Exception.Message)"
    } finally {
        if ($null -ne $handle) { $handle.Close() }
    }
}

# ------------------------------------------------------------------
# 主流程
# ------------------------------------------------------------------

$script:Protected = Get-ProtectedPaths

# 这是一个普通的维护脚本：保留可见的控制台窗口并输出进度，不做任何隐藏或混淆，
# 这样用户能看到它做了什么，也不会因为“隐藏窗口 + 自删除”被当成恶意脚本。
try { $Host.UI.RawUI.WindowTitle = 'TCL 卸载清理（完成后自动关闭）' } catch { }
Write-Host '正在卸载 TCraft Launcher，请稍候……'
Write-Host ''

# 允许操作的位置：安装目录、桌面、开始菜单、AppData、临时目录
$rootCandidates = @(
    (Normalize-Path $InstallDir),
    (Normalize-Path ([System.Environment]::GetFolderPath('Desktop'))),
    (Normalize-Path ([System.Environment]::GetFolderPath('StartMenu'))),
    (Normalize-Path $env:APPDATA),
    (Normalize-Path $env:TEMP)
)
$script:AllowedRoots = @($rootCandidates | Where-Object { $_ -and $_.Length -gt 2 })

Write-Log 'INFO' '================ TCL 卸载清理开始 ================'
Write-Log 'INFO' "脚本路径：$PSCommandPath"
Write-Log 'INFO' "父进程 PID：$ParentPid；延迟：$DelaySeconds 秒"
Write-Log 'INFO' "安装目录：$InstallDir"
Write-Log 'INFO' "目标：$Targets"
Write-Log 'INFO' "注册表：$RegKeys"
Write-Host "清理范围：$(($Targets -split ';' | Where-Object { $_ }).Count) 个文件/目录，$(($RegKeys -split ';' | Where-Object { $_ }).Count) 个注册表项"
Write-Host ''

# 0. 空清单直接退出：参数异常时宁可什么都不做，也不乱删
if ([string]::IsNullOrWhiteSpace($Targets) -and [string]::IsNullOrWhiteSpace($RegKeys)) {
    Write-Log 'WARN' '没有收到任何清理目标，脚本不会执行任何删除'
    Write-Host '没有收到清理目标，已退出。'
    try { [System.IO.File]::Delete($PSCommandPath) } catch { }
    exit 0
}

# 1. 等待启动器进程退出，确保文件句柄全部释放
if ($ParentPid -gt 0) {
    try {
        $parent = Get-Process -Id $ParentPid -ErrorAction Stop
        Write-Log 'INFO' "等待启动器进程退出（PID $ParentPid）……"
        if (-not $parent.WaitForExit(30000)) { Write-Log 'WARN' '等待启动器退出超时（30 秒），继续执行' }
    } catch {
        Write-Log 'INFO' "启动器进程（PID $ParentPid）已退出"
    }
}

# 2. 额外等待，避开退出瞬间仍在刷盘或写日志的竞态
$delay = [Math]::Max(0, $DelaySeconds)
if ($delay -gt 0) { Start-Sleep -Seconds $delay }
Write-Log 'INFO' "等待结束，开始清理"
Write-Host '正在清理启动器文件……'

# 3. 目录与文件
foreach ($raw in ($Targets -split ';')) {
    $entry = $raw.Trim()
    if ([string]::IsNullOrWhiteSpace($entry)) { continue }

    $parts = $entry.Split('|')
    if ($parts.Count -lt 2) {
        $script:SkipCount++
        Write-Log 'WARN' "无法解析的目标，已跳过：$entry"
        continue
    }

    $kind = $parts[0].Trim().ToUpperInvariant()
    $path = $parts[1].Trim()

    if ($kind -eq 'FILE') {
        $reason = Test-SafePath -Path $path -Kind 'File'
        if ($reason) {
            $script:SkipCount++
            Write-Log 'SKIP' "已拒绝文件（$reason）：$path"
            continue
        }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            $script:SkipCount++
            Write-Log 'SKIP' "文件不存在，已跳过：$path"
            continue
        }
        Remove-FileWithRetry -Path $path | Out-Null
        continue
    }

    if ($kind -eq 'DIR' -or $kind -eq 'DIR_IF_EMPTY') {
        $checkKind = if ($kind -eq 'DIR') { 'Dir' } else { 'DirIfEmpty' }
        $reason = Test-SafePath -Path $path -Kind $checkKind
        if ($reason) {
            $script:SkipCount++
            Write-Log 'SKIP' "已拒绝目录（$reason）：$path"
            continue
        }
        if (-not (Test-Path -LiteralPath $path -PathType Container)) {
            $script:SkipCount++
            Write-Log 'SKIP' "目录不存在，已跳过：$path"
            continue
        }

        if ($kind -eq 'DIR_IF_EMPTY') {
            # 安装目录：只删除已经空了的目录，绝不碰同目录下不属于启动器的文件
            try {
                $left = @(Get-ChildItem -LiteralPath $path -Force -ErrorAction Stop)
                if ($left.Count -eq 0) {
                    [System.IO.Directory]::Delete($path, $false)
                    $script:OkCount++
                    Write-Log 'OK' "已删除空目录：$path"
                } else {
                    $script:SkipCount++
                    Write-Log 'SKIP' "安装目录仍有 $($left.Count) 个非启动器文件，保留：$path"
                }
            } catch {
                $script:FailCount++
                Write-Log 'FAIL' "删除空目录失败：$path → $($_.Exception.Message)"
            }
            continue
        }

        Write-Log 'INFO' "开始删除目录：$path"
        Write-Host "  正在删除目录：$path"
        Remove-SafeTree -Dir $path
        continue
    }

    $script:SkipCount++
    Write-Log 'WARN' "未知的目标类型（$kind），已跳过：$entry"
}

# 4. 注册表
foreach ($raw in ($RegKeys -split ';')) {
    $entry = $raw.Trim()
    if ([string]::IsNullOrWhiteSpace($entry)) { continue }

    $parts = $entry.Split('|')
    if ($parts.Count -lt 2) {
        $script:SkipCount++
        Write-Log 'WARN' "无法解析的注册表条目，已跳过：$entry"
        continue
    }

    $kind = $parts[0].Trim().ToUpperInvariant()
    if ($kind -eq 'KEY') {
        Remove-RegKey -KeyPath $parts[1].Trim()
    } elseif ($kind -eq 'VAL') {
        if ($parts.Count -lt 3) {
            $script:SkipCount++
            Write-Log 'WARN' "注册表值条目缺少值名，已跳过：$entry"
            continue
        }
        Remove-RegValue -KeyPath $parts[1].Trim() -ValueName $parts[2]
    } else {
        $script:SkipCount++
        Write-Log 'WARN' "未知的注册表类型（$kind），已跳过：$entry"
    }
}

Write-Host ""
Write-Host "清理完成：成功 $($script:OkCount) 项，跳过 $($script:SkipCount) 项，失败 $($script:FailCount) 项"

if ($script:FailCount -gt 0) {
    Write-Log 'INFO' "存在失败项，日志已保留：$LogPath"
    Write-Log 'INFO' '可手动删除日志文件；若删除失败是因为权限不足，请以管理员身份重试对应目录。'
    Write-Host "有 $($script:FailCount) 项没能删除，日志已保留在："
    Write-Host "  $LogPath"
} else {
    Write-Log 'INFO' '全部清理成功，脚本与日志即将自毁。'
}

# 5. 自毁
# 说明：PowerShell 可以直接删除正在运行的脚本文件（脚本在执行前已读入内存），
# 因此这里不再拉起 cmd /c ping & del —— 那种写法是典型的恶意软件特征，容易被杀软拦截。
try {
    if ($script:FailCount -eq 0 -and -not $KeepLog -and -not [string]::IsNullOrWhiteSpace($LogPath)) {
        [System.IO.File]::Delete($LogPath)
        try {
            [System.IO.Directory]::Delete((Split-Path -Parent $LogPath), $false)
        } catch { }
    }
} catch { }

try {
    [System.IO.File]::Delete($PSCommandPath)
} catch {
    # 删除失败就把脚本留在临时目录里，不影响系统，也不会被反复执行
}
